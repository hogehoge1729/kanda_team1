var myElement = document.getElementById('btn-favolite');
myElement.addEventListener('click', function() {
	window.location.href = '/'; // 遷移先のURLを指定
});

var myElement = document.getElementById('btn-itemlist');
myElement.addEventListener('click', function() {
	window.location.href = '/product'; // 遷移先のURLを指定
});
