//このファイル名とxmlのURLパターンがが正しいか確認したら、このコメントを消してください
//URL http://localhost:8080/kanda_team1/view/memberInformationScreen.jsp
//内容 ：ユーザー情報変更
//作成者：福本唯人

package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.MemberDTO;
import dao.MemberDAO;

public class UserUpdateServlet extends HttpServlet {

	String error = "";

	// ポスト送信
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 入力データの文字コードの指定
		request.setCharacterEncoding("UTF-8");

		String error = "";
		String cmd = "";
		MemberDTO objMember = new MemberDTO();
		MemberDAO memberDao = new MemberDAO();
		HttpSession session = request.getSession();
		MemberDTO memberinfo = (MemberDTO) session.getAttribute("member");
		try {
			// セッション切れの場合はerror.jspに遷移する
			if (memberinfo == null) {
				error = "セッション切れ又はログインしていません";
				cmd = "error";
				return;
			}



			// isbn,title,price等の入力パラメータを取得する
			String kanjiFamilyName = request.getParameter("KanjiFamilyName");
			String kanjiFirstName = request.getParameter("KanjiFirstName");

			String kanaFamilyName = request.getParameter("KanaFamilyName");
			String kanaFirstName = request.getParameter("KanaFirstName");

			String telephoneNumber = request.getParameter("TelephoneNumber");
			String residence = request.getParameter("residence");
			String membername = request.getParameter("membername");
			String mail = request.getParameter("mail");

			String newpass = request.getParameter("newpass");
			String oldpass = request.getParameter("oldpass");

			// パスワード確認

			if (oldpass == null || oldpass.equals("")) {
				error = "旧パスワードが未入力のため、メンバー情報が変更できませんでした。";
				return;
			}
			String oldMail=memberinfo.getMail();
			MemberDTO memberDto = memberDao.selectByMember(oldMail, oldpass);
			if(memberDto.getMail() == null) {
				error = "旧パスワードが間違っています！";
				return;

			}

			if (kanjiFamilyName == null || kanjiFamilyName.equals("")) {
				error = "漢字・姓が未入力のため、メンバー情報が変更できませんでした。";
				return;
			}
			if (kanjiFirstName == null || kanjiFirstName.equals("")) {
				error = "漢字・名が未入力のため、メンバー情報が変更できませんでした。";
				return;
			}
			if (kanaFamilyName == null || kanaFamilyName.equals("")) {
				error = "かな・姓が未入力のため、メンバー情報が変更できませんでした。";
				return;
			}
			if (kanaFirstName == null || kanaFirstName.equals("")) {
				error = "かな・名が未入力のため、メンバー情報が変更できませんでした。";
				return;
			}
			if (telephoneNumber == null || telephoneNumber.equals("")) {
				error = "電話番号が未入力のため、メンバー情報が変更できませんでした。";
				return;
			}
			if (residence == null || residence.equals("")) {
				error = "住所が未入力のため、メンバー情報が変更できませんでした。";
				return;
			}
			if (membername == null || membername.equals("")) {
				error = "ユーザー名が未入力のため、メンバー情報が変更できませんでした。";
				return;
			}
			if (mail == null || mail.equals("")) {
				error = "メールアドレスが未入力のため、メンバー情報が変更できませんでした。";
				return;
			}

			if (newpass == null || newpass.equals("")) {
				error = "新パスワードが未入力のため、メンバー情報が変更できませんでした。";
				return;
			}

			objMember.setMemberId(memberinfo.getMemberId());
			objMember.setKanjiFamilyName(kanjiFamilyName);
			objMember.setKanjiFirstName(kanjiFirstName);
			objMember.setKanaFamilyName(kanaFamilyName);
			objMember.setKanaFirstName(kanaFirstName);
			objMember.setTelephoneNumber(telephoneNumber);
			objMember.setResidence(residence);
			objMember.setMamberName(membername);
			objMember.setMail(mail);
			objMember.setPassword(newpass);

			memberDao.MemberUpdatet(objMember);


			session.setAttribute("member",null);

		} catch (Exception e) {
			System.out.println("エラー(;A;)" + e);
			error="想定外のエラー";
		} finally {
			// 正常なフォワード
			if (error.equals("")) {
				request.getRequestDispatcher("/view/login.jsp").forward(request, response);
			}
			// エラーへのフォワード
			else {
				// エラーメッセージををセット
				request.setAttribute("error", error);
				// フォワード
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}