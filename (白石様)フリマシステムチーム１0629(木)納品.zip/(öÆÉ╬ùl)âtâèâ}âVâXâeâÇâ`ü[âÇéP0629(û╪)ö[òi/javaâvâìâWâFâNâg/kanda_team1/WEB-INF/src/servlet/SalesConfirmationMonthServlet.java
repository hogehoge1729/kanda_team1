//このファイル名とxmlのURLパターンがが正しいか確認したら、このコメントを消してください
//内容  ：
//作成者：
package servlet;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.SellDTO;
import dao.AdminDAO;
import dao.SellDAO;

public class SalesConfirmationMonthServlet extends HttpServlet {

	String error = "";

	// ポスト送信
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
		try {
			// 文字コードを設定する
			request.setCharacterEncoding("UTF-8");

			// 各入力パラメータを取得する
			String month =request.getParameter("month");
			String year =request.getParameter("year");

			//リスト作成
			ArrayList<SellDTO> list = new SellDAO().selectAllValue();

			request.setAttribute("sale_List", list);

			//
			if(month == null || month.equals("")) {
				return ;
			}
			if(year == null || year.equals("")) {
				return;
			}


			//絞り込み
			for(int i=0;i<list.size();i++) {

				String day = list.get(i).getSellDate();



				if(!(day.substring(0, Math.min(day.length(), 4)).equals(year))) {
					list.remove(i);
				}
				else if(!(String.valueOf(day.charAt(5))+String.valueOf(day.charAt(6))).equals(month)) {
					list.remove(i);
				}
			}






		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			System.out.println("エラー(;A;)" + e);
		}
		catch(Exception e){
			error="想定外のエラー";
		}finally {

			try {

				// 正常なフォワード
				if (error.equals("")) {
					request.getRequestDispatcher("/view/saleConfirmationScreen.jsp").forward(request, response);
				}
				// エラーへのフォワード
				else {

					// エラーメッセージををセット
					request.setAttribute("who", "admin");

					// エラーメッセージををセット
					request.setAttribute("error", error);
					// フォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			} catch (Exception e) {
			}
		}
	}

}
