//このファイル名とxmlのURLパターンがが正しいか確認したら、このコメントを消してください
//内容  ：
//作成者：
package servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ListingCompletionScreenServlet extends HttpServlet {

	String error = "";

	// ポスト送信
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
		try {

			// 処理

		} catch (Exception e) {
			System.out.println("エラー(;A;)" + e);
			error="想定外のエラー";
		} finally {
			try {

				// 正常なフォワード
				if (error.equals("")) {
					//request.getRequestDispatcher(" 飛ばし先のパス<view/なんちゃらとか> ").forward(request, response);
				}
				// エラーへのフォワード
				else {
					// エラーメッセージををセット
					request.setAttribute("error", error);
					// フォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			} catch (Exception e) {
			}
		}
	}

}
