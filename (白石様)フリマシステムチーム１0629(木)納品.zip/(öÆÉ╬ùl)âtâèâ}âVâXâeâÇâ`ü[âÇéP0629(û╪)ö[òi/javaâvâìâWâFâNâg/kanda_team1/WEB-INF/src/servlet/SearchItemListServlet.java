//⇒ファイル名違ったので変更しました
//内容  ：商品一覧から検索できる。商品名と、値段の上限、下限と、都道府県と、商品状態による絞り込み
//作成者：森菜乃子
package servlet;

import java.util.ArrayList;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.MemberDTO;
import bean.SellDTO;
import dao.MemberDAO;
import dao.SellDAO;

public class SearchItemListServlet extends HttpServlet {

	String error = "";
	ArrayList<SellDTO> list = new ArrayList<SellDTO>();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) {

		//セッションオブジェクト
		HttpSession session = request.getSession();

		try {
			//文字エンコーディングの指定
			request.setCharacterEncoding("UTF-8");

			//パラメータの取得
			String productName = request.getParameter("product_type");
			String price1 = request.getParameter("upperPrice");
			String price2 = request.getParameter("lowerPrice");
			String prefecturesId = request.getParameter("prefectures");
			String productCondition = request.getParameter("product_condition");
			String strSort = request.getParameter("sortType");

			//オブジェクト化
			SellDAO sellDao = new SellDAO();

			//結果の戻り値としてBookオブジェクトのリストを取得
			list = sellDao.search(productName, price1, price2, prefecturesId, productCondition);





			//sortによって並び順変える
			if(strSort != null){	//並び替え押したなら
				int sort = Integer.parseInt(strSort);
				if(sort == 1) {				//安い順
					list = sellDao.sortCheap();
				}else if(sort == 2) {		//高い順
					list = sellDao.sortExpensive();
				}else if(sort == 3) {		//出品日新しい順
					list = sellDao.sortNew();
				}
			}

			//自身のメンバーid取得
			MemberDTO memberinfo = (MemberDTO) session.getAttribute("member");

			//自身のアカウントのものは除外
			if(memberinfo!=null) {
				int myId=memberinfo.getMemberId();

				for(int i=0;i<list.size();i++) {
					if(list.get(i).getSellerMemberId()==myId) {
						list.remove(i);
						i--;
					}
				}
			}

			//凍結アカウントのものは除外
			for(int i=0;i<list.size();i++) {
				if(new MemberDAO().selectByMember(list.get(i).getSellerMemberId()).getAccountStatus()==2) {
					list.remove(i);
					i--;
				}
			}


		} catch (Exception e) {
			System.out.println("エラー(;A;)" + e);
			error="想定外のエラー";
		} finally {
			try {

				// 正常なフォワード
				if (error.equals("")) {
					//セッションにデータを登録してフォワード
					session.setAttribute("order_list", list);
					request.getRequestDispatcher("/view/itemList.jsp").forward(request, response);
				}
				// エラーへのフォワード
				else {
					// エラーメッセージををセット
					request.setAttribute("error", error);
					// フォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			} catch (Exception e) {
			}
		}
	}

}
