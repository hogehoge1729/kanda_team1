//このファイル名とxmlのURLパターンがが正しいか確認したら、このコメントを消してください
//内容  ：お気に入り登録
//作成者：平瀬
package servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.MemberDTO;
import dao.SellDAO;

public class FavoriteInsertServlet extends HttpServlet {

	String error = "";

	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		try {

			//DAOオブジェクト宣言
			SellDAO sellDao = new SellDAO();

			//セッションから"user"のUserオブジェクトを取得する(セッション切れの場合はエラー)。
			HttpSession session = request.getSession();
			MemberDTO member = (MemberDTO)session.getAttribute("member");

			if(member == null){
				error="ログインしていないかセッション切れです";
				return;
			}

			//パラメータの取得
			int memberId = member.getMemberId();
			String sellId = request.getParameter("sellId");

			//登録済みは削除
			if(sellDao.check(memberId, sellId)) {
				sellDao.favDelte(memberId, sellId);
			}
			//未登録は登録
			else {
				sellDao.insert(memberId, sellId);
			}



		} catch (Exception e) {
			System.out.println("エラー(;A;)" + e);
			error="想定外のエラー";
		} finally {
			try {

				// 正常なフォワード
				if (error.equals("")) {
					request.getRequestDispatcher("/favoritelist").forward(request, response);
				}
				// エラーへのフォワード
				else {
					// エラーメッセージををセット
					request.setAttribute("error", error);
					// フォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			} catch (Exception e) {
			}
		}
	}

}
