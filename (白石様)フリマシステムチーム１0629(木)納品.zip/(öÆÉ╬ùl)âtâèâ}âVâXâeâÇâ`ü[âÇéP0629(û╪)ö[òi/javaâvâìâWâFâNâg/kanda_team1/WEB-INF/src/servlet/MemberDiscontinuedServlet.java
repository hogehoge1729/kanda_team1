//このファイル名とxmlのURLパターンがが正しいか確認したら、このコメントを消してください
//内容  ：
//作成者：
package servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.MemberDTO;
import dao.MemberDAO;

public class MemberDiscontinuedServlet extends HttpServlet {

	String error = "";

	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		try {

			//文字コーディングの指定
			request.setCharacterEncoding("UTF-8");

			//入力パラメーターの取得
			String search = request.getParameter("search");
			String memberId = request.getParameter("memberId");

			System.out.println(memberId);

			int status = 0;

			if (search.equals("凍結")) {
				status = 2;
			}else if (search.equals("凍結解除")) {
				status = 0;
			}else if (search.equals("通報解除")) {
				status = 0;
			}

			MemberDTO member = new MemberDTO();

			member.setAccountStatus(status);
			member.setMemberId(Integer.parseInt(memberId));

			//DAOのオブジェクト宣言
			MemberDAO memberDao = new MemberDAO();

			//DAOから更新メソッドを呼び出し
			memberDao.statusUpdate(member);


		} catch (Exception e) {
			System.out.println("エラー(;A;)" + e);
			error="想定外のエラー";
		} finally {
			try {

				// 正常なフォワード
				if (error.equals("")) {
					request.getRequestDispatcher("/member").forward(request, response);
				}
				// エラーへのフォワード
				else {
					// エラーメッセージををセット
					request.setAttribute("error", error);
					// フォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			} catch (Exception e) {
			}
		}
	}

}
