package servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.servlet.http.HttpServlet;
import com.oreilly.servlet.MultipartRequest;

import bean.SellDTO;
import dao.MemberDAO;
import dao.SellDAO;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

import javax.servlet.ServletException;

public class ItemInsertServlet extends HttpServlet{



	// ポスト送信
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException{
		String error = "";
		request.setCharacterEncoding("UTF-8");
		SellDTO sell = new SellDTO();
		try {

			//Part part=request.getPart("pict");
			//ファイル名を取得
			//String filename=part.getSubmittedFileName();//ie対応が不要な場合
			//tring filename=Paths.get(part.getSubmittedFileName()).getFileName().toString();
			String FilePath = getServletContext().getRealPath("image");
			//part.write(Path+File.separator+filename);
			//String file = Path+File.separator+filename;


			//ファイル名
			String imageName = "no_image.jpg";
			// ファイルの最大バイト数
			int maxBytes = 1024*1024;
			MultipartRequest multireq=new MultipartRequest(request,FilePath,maxBytes,"UTF-8");
			if(multireq.getFile("image") != null){
				imageName = multireq.getFile("image").getName();
			}
			String itemName = multireq.getParameter("itemName");

			String type = multireq.getParameter("type");
			if(type == null || type.equals("")) {
				error = "種類を入力してください";
				return;
			}
			String productStatus = multireq.getParameter("productStatus");
			if(productStatus == null || productStatus.equals("")) {
				error = "商品状態を入力してください";
				return;
			}
			String price = multireq.getParameter("price");
			if(price == null || price.equals("")) {
				error = "価格を入力してください";
				return;
			}
			String pref = request.getParameter("pref");
			String remarks = multireq.getParameter("remarks");
			if(price == null || price.equals("")) {
				error = "備考欄を入力してください";
				return;
			}
			String delivaryDay = multireq.getParameter("delivaryDay");

			sell.setDeliveryDays(Integer.parseInt(delivaryDay));
			sell.setPurchaserMemberId(1);
			sell.setSellerMemberId(1);
			sell.setImagePath("/image/" + imageName);
			sell.setProductName(itemName);
			sell.setProductType(type);
			sell.setProductCondition(productStatus);
			sell.setPrice(Integer.parseInt(price));
			sell.setPrefectures(pref);
			sell.setRemarks(remarks);

			SellDAO objSell = new SellDAO();
			objSell.itemInsert(sell);




		}catch(NumberFormatException e) {
			error = "不正な値です。";
		}

		catch (IllegalStateException e) {
			error = "データベース接続時にエラーが発生しました。";
			System.out.println(e);

		}catch(Exception e){
			System.out.println(e);
		}	finally {
		}
			try {

				// 正常なフォワード
				if (error.equals("")) {
					request.getRequestDispatcher("view/listingCompletionScreen.jsp").forward(request, response);
				}
				// エラーへのフォワード
				else {
					// エラーメッセージををセット
					request.setAttribute("error", error);
					// フォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			} catch (Exception e) {
			}
		}
	}



