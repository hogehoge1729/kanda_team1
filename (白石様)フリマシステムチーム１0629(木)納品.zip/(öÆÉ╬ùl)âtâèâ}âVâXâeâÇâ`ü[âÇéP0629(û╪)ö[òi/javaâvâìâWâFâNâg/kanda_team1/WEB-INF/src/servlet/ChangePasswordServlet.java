//このファイル名とxmlのURLパターンがが正しいか確認したら、このコメントを消してください
//内容  ：管理者パスワード変更
//作成者：平瀬奈緒
package servlet;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.AdminDAO;
import bean.AdminDTO;

public class ChangePasswordServlet extends HttpServlet {

	String error = "";

	// ポスト送信
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
		try {

			//DAOオブジェクト宣言
			AdminDAO adminDao = new AdminDAO();

			//入力パラメーターの取得
			HttpSession session = request.getSession();
			AdminDTO admin = (AdminDTO) session.getAttribute("admin");
			String passwordOld = request.getParameter("passwordOld");
			String passwordNew = request.getParameter("passwordNew");
			String passwordNewCheck = request.getParameter("passwordNewCheck");

			//登録ボタン押下時、パスワード(旧)が未入力エラー
			if(passwordOld.equals("")){
				error = "パスワード(旧)が未入力の為、変更処理は行えませんでした。";
				return;
			}

			//登録ボタン押下時、パスワード(旧)が未入力エラー
			if(passwordNew.equals("")){
				error = "パスワード(新)が未入力の為、変更処理は行えませんでした。";
				return;
			}

			//登録ボタン押下時、パスワード(旧)が未入力エラー
			if(passwordNewCheck.equals("")){
				error = "パスワード(新・確認)が未入力の為、変更処理は行えませんでした。";
				return;
			}

			//登録ボタン押下時、パスワード(新)とパスワード(新・確認)が不一致エラー
			if(!passwordNewCheck.equals(passwordNew)){
				error = "パスワード(新)とパスワード(新・確認)が同じではありません。";
				return;
			}

			System.out.println(admin.getMail() );
			//管理者のメールアドレスを取得
			String mail = admin.getMail();

			//DTOオブジェクト宣言
			AdminDTO adminPass = new AdminDTO();

			//入力したパスワード(旧)が正しくない場合エラーを表示する
			adminPass = adminDao.selectByAdmin(mail, passwordOld);

			if(!admin.getPass().equals(passwordOld)){
				error = "パスワード(旧)が正しくありません。";
				return;
			}

			//入力データをDTOに格納
			admin.setPass(passwordNew);

			//DAOから更新メソッドを呼び出し
			adminDao.update(admin);

			//リクエストスコープへデータを登録する
			request.setAttribute("adminPass", adminPass);


		} catch (Exception e) {
			System.out.println("エラー(;A;)" + e);
			error="想定外のエラー";
		} finally {
			try {

				// 正常なフォワード
				if (error.equals("")) {
					request.getRequestDispatcher("/view/menu.jsp").forward(request, response);
				}
				// エラーへのフォワード
				else {
					// エラーメッセージををセット
					request.setAttribute("who", "admin");

					// エラーメッセージををセット
					request.setAttribute("error", error);
					// フォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			} catch (Exception e) {
			}
		}
	}
}