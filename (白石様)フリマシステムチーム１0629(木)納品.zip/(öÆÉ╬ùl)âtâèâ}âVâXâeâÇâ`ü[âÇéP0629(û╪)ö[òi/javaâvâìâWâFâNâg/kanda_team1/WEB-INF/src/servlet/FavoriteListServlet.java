//内容  ：商品一覧からお気に入り一覧ボタンと押下するとお気に入りに登録した商品が一覧表示される
//作成者：森菜乃子
package servlet;

import java.util.ArrayList;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.MemberDTO;
import bean.SellDTO;
import dao.SellDAO;

public class FavoriteListServlet extends HttpServlet {



	protected void doGet(HttpServletRequest request, HttpServletResponse response) {

		String error = "";
		ArrayList<SellDTO> list = new ArrayList<SellDTO>();

		try {
			// SellDAOオブジェクト生成
			SellDAO sellDao = new SellDAO();

			//ログイン情報取得
			HttpSession session = request.getSession();
			MemberDTO memberinfo = (MemberDTO) session.getAttribute("member");


			// セッション切れの場合はerror.jspに遷移する
			if (memberinfo == null) {
				error = "セッション切れ又はログインしていません";
				return;
			}

			//お気に入り一覧メソッドを呼び出しArrayListに格納
			list = sellDao.selectFavorite(memberinfo.getMemberId());


			//セッションにデータを登録してフォワード
			session.setAttribute("order_list", list);

			request.setAttribute("cmd", "fav");

		} catch (Exception e) {
			System.out.println("エラー(;A;)" + e);
			error="想定外のエラー";
		} finally {
			try {

				// 正常なフォワード
				if (error.equals("")) {
					request.getRequestDispatcher("/view/itemList.jsp").forward(request, response);
				}
				// エラーへのフォワード
				else {
					// エラーメッセージををセット
					request.setAttribute("error", error);
					// フォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			} catch (Exception e) {
			}
		}
	}

}
