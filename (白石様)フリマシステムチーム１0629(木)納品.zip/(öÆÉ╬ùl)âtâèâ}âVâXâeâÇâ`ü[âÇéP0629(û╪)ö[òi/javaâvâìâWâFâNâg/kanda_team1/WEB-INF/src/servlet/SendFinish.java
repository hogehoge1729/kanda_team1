//このファイル名とxmlのURLパターンがが正しいか確認したら、このコメントを消してください
//内容  ：
//作成者：
package servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.MemberDTO;
import bean.SellDTO;
import dao.MemberDAO;
import dao.SellDAO;
import util.SendMailTest;

public class SendFinish extends HttpServlet {

	String error = "";

	// ゲット送信
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		try {

			String sellId = request.getParameter("sellId");

			new SellDAO().statusUpdate(sellId,"発送完了");



			SellDTO sellDTO =new SellDAO().selectBySellId(sellId);

			int purcharser = sellDTO.getPurchaserMemberId();

			String mail = new MemberDAO().selectByMember(purcharser).getMail();


			//メール送信
			SendMailTest.mailBuy(
					"配送通知",
					"購入した商品が発送されました。\n"
					+"商品が届いたら、受け取り完了ボタンを押してください。",
					mail);



		} catch (Exception e) {
			System.out.println("エラー(;A;)" + e);
			error="想定外のエラー";
		} finally {
			try {

				// 正常なフォワード
				if (error.equals("")) {
					request.getRequestDispatcher("/ExhibitList").forward(request, response);
				}
				// エラーへのフォワード
				else {
					// エラーメッセージををセット
					request.setAttribute("error", error);
					// フォワード
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			} catch (Exception e) {
			}
		}
	}

}
