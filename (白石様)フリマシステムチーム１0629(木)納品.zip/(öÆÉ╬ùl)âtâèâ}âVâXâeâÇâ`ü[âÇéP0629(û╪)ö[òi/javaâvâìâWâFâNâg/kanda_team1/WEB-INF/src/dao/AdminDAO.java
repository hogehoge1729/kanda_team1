package dao;

import java.sql.*;
import java.util.ArrayList;

import bean.AdminDTO;
import bean.MemberDTO;
import bean.SellDTO;

public class AdminDAO {

	// 接続用情報
	private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost/kandadb";
	private static final String USER = "root";
	private static final String PASSWD = "root123";

	// DB接続
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public void update(AdminDTO admin) {

		// 変数宣言
		Connection con = null;
		Statement smt = null;

		try {

			// SQL文
			String sql = "UPDATE administrator SET password='" + admin.getPass() + "' WHERE mail='" + admin.getMail()
					+ "'";

			// DBに接続
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}

			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public AdminDTO selectByAdmin(String mail, String pass) {
		Connection con = null;
		Statement smt = null;
		AdminDTO admin = new AdminDTO();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT * FROM administrator WHERE mail='" + mail + "' AND password='" + pass + "'";

			ResultSet rs = smt.executeQuery(sql);

			if (rs.next()) {
				admin.setMail(rs.getString("mail"));
				admin.setPass(rs.getString("password"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}

		return admin;
	}

	// DBから会員情報の全てを検索
	public ArrayList<MemberDTO> selectAll() {
		// return用オブジェクト生成
		ArrayList<MemberDTO> list = new ArrayList<MemberDTO>();
		// SQL文
		String sql = "SELECT * FROM member_Info";

		Connection con = null;
		Statement smt = null;
		try {
			con = AdminDAO.getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果を配列に格納
			while (rs.next()) {
				MemberDTO member = new MemberDTO();
				member.setMemberId(rs.getInt("member_id"));
				member.setMamberName(rs.getString("member_name"));
				member.setPassword(rs.getString("password"));
				member.setKanjiFamilyName(rs.getString("kanji_family_name"));
				member.setKanjiFirstName(rs.getString("kanji_first_name"));
				member.setKanaFamilyName(rs.getString("kana_family_name"));
				member.setKanaFirstName(rs.getString("kana_first_name"));
				member.setResidence(rs.getString("residence"));
				member.setMail(rs.getString("mail"));
				member.setTelephoneNumber(rs.getString("telephone_number"));
				member.setAccountStatus(rs.getInt("account_status"));
				list.add(member);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return list;
	}

	// 通報された人絞り込み検索
	public ArrayList<MemberDTO> search(String mamberName, String kanjiFamilyName, String kanjiFirstName, String mail,
			String residence, String accountStatus) {
		Connection con = null;
		Statement smt = null;

		// return用オブジェクト生成
		ArrayList<MemberDTO> list = new ArrayList<MemberDTO>();

		// SQL文
		String sql = "SELECT * FROM member_Info " + "WHERE member_name LIKE '%" + mamberName
				+ "%' AND kanji_family_name LIKE '%" + kanjiFamilyName + "%' AND kanji_first_name LIKE '%"
				+ kanjiFirstName + "%' AND mail LIKE '%" + mail + "%' AND residence LIKE '%" + residence
				+ "%' AND account_status = 1";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果を配列に格納
			while (rs.next()) {
				MemberDTO member = new MemberDTO();
				member.setMemberId(rs.getInt("member_id"));
				member.setMamberName(rs.getString("member_name"));
				member.setPassword(rs.getString("password"));
				member.setKanjiFamilyName(rs.getString("kanji_family_name"));
				member.setKanjiFirstName(rs.getString("kanji_first_name"));
				member.setKanaFamilyName(rs.getString("kana_family_name"));
				member.setKanaFirstName(rs.getString("kana_first_name"));
				member.setResidence(rs.getString("residence"));
				member.setMail(rs.getString("mail"));
				member.setTelephoneNumber(rs.getString("telephone_number"));
				member.setAccountStatus(rs.getInt("account_status"));
				list.add(member);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			// リソースの解放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return list;
	}

	// 会員絞り込み検索
	public ArrayList<MemberDTO> search(String mamberName, String kanjiFamilyName, String kanjiFirstName, String mail,
			String residence, int accountStatus) {
		Connection con = null;
		Statement smt = null;

		// return用オブジェクト生成
		ArrayList<MemberDTO> list = new ArrayList<MemberDTO>();

		// SQL文
		String sql = "SELECT * FROM member_Info " + "WHERE member_name LIKE '%" + mamberName
				+ "%' AND kanji_family_name LIKE '%" + kanjiFamilyName + "%' AND kanji_first_name LIKE '%"
				+ kanjiFirstName + "%' AND mail LIKE '%" + mail + "%' AND residence LIKE '%" + residence
				+ "%' AND account_status = " + accountStatus;

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果を配列に格納
			while (rs.next()) {
				MemberDTO member = new MemberDTO();
				member.setMemberId(rs.getInt("member_id"));
				member.setMamberName(rs.getString("member_name"));
				member.setPassword(rs.getString("password"));
				member.setKanjiFamilyName(rs.getString("kanji_family_name"));
				member.setKanjiFirstName(rs.getString("kanji_first_name"));
				member.setKanaFamilyName(rs.getString("kana_family_name"));
				member.setKanaFirstName(rs.getString("kana_first_name"));
				member.setResidence(rs.getString("residence"));
				member.setMail(rs.getString("mail"));
				member.setTelephoneNumber(rs.getString("telephone_number"));
				member.setAccountStatus(rs.getInt("account_status"));
				list.add(member);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			// リソースの解放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return list;
	}

	// 出品した人絞り込み検索
	public ArrayList<MemberDTO> searchShopper(String mamberName, String kanjiFamilyName, String kanjiFirstName,
			String mail, String residence, int accountStatus) {
		Connection con = null;
		Statement smt = null;

		// return用オブジェクト生成
		ArrayList<MemberDTO> list = new ArrayList<MemberDTO>();

		// SQL文
		String sql = "SELECT DISTINCT sell.seller_member_id, member_info. * FROM sell "
				+ "INNER JOIN member_info ON sell.seller_member_id = member_info.member_id "
				+ "WHERE member_name LIKE '%" + mamberName + "%' AND kanji_family_name LIKE '%" + kanjiFamilyName
				+ "%' AND kanji_first_name LIKE '%" + kanjiFirstName + "%' AND mail LIKE '%" + mail
				+ "%' AND residence LIKE '%" + residence + "%' AND account_status = " + accountStatus;

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果を配列に格納
			while (rs.next()) {
				MemberDTO member = new MemberDTO();
				member.setMemberId(rs.getInt("member_id"));
				member.setMamberName(rs.getString("member_name"));
				member.setPassword(rs.getString("password"));
				member.setKanjiFamilyName(rs.getString("kanji_family_name"));
				member.setKanjiFirstName(rs.getString("kanji_first_name"));
				member.setKanaFamilyName(rs.getString("kana_family_name"));
				member.setKanaFirstName(rs.getString("kana_first_name"));
				member.setResidence(rs.getString("residence"));
				member.setMail(rs.getString("mail"));
				member.setTelephoneNumber(rs.getString("telephone_number"));
				member.setAccountStatus(rs.getInt("account_status"));
				list.add(member);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			// リソースの解放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return list;
	}


	//DBから商品画像と商品名と値段を検索
	public ArrayList<SellDTO> selectAllSell()	{
		//return用オブジェクト生成
		ArrayList<SellDTO> list = new ArrayList<SellDTO>();
		//SQL文
		String sql = "SELECT * FROM sell where transfer_date IS NOT NULL";
				//"SELECT * FROM sell WHERE product_condition = '受け取り完了'";

		Connection con = null;
		Statement  smt = null;
		try{
			con = SellDAO.getConnection();
			smt = con.createStatement();

			//SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			//検索結果を配列に格納
			while(rs.next()){
				SellDTO sellDto = new SellDTO();
				sellDto.setSellId(rs.getInt("sell_id"));
				sellDto.setSellerMemberId(rs.getInt("seller_member_id"));
				sellDto.setPurchaserMemberId(rs.getInt("purchaser_member_id"));
				sellDto.setProductName(rs.getString("product_name"));
				sellDto.setProductType(rs.getString("product_type"));
				sellDto.setPrice(rs.getInt("price"));
				sellDto.setPrefectures(rs.getString("prefectures"));
				sellDto.setRemarks(rs.getString("remarks"));
				sellDto.setDeliveryDays(rs.getInt("delivery_days"));
				sellDto.setProductCondition(rs.getString("product_condition"));
				sellDto.setImagePath(rs.getString("image_path"));
				sellDto.setSellStatus(rs.getString("sell_status"));
				sellDto.setSellDate(rs.getString("sell_date"));
				sellDto.setPurchaseDate(rs.getString("purchase_date"));
				sellDto.setTransferDate(rs.getString("transfer_date"));
				sellDto.setShipmentDate(rs.getString("shipment_date"));
				sellDto.setCompletionDate(rs.getString("completion_date"));
				list.add(sellDto);
			}

		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if(smt != null){
				try{smt.close();}catch(SQLException ignore){}
			}
			if(con != null){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return list;
	}

	//DBから商品画像と商品名と値段を検索
		public ArrayList<SellDTO> dateSelectAll(String month,String year)	{
			//return用オブジェクト生成
			ArrayList<SellDTO> list = new ArrayList<SellDTO>();



					// "SELECT * FROM sell WHERE transfer_date BETWEEN 1 AND 30";
					//"SELECT * FROM sell WHERE product_condition = '受け取り完了'";

			Connection con = null;
			con = SellDAO.getConnection();;
			String sql ="SELECT * FROM sell WHERE transfer_date LIKE ? AND transfer_date IS NOT NULL;";
			PreparedStatement statement = null;
			try{

				statement = con.prepareStatement(sql);

				String day1 = year + "-" + month ;

				statement.setString(1, day1 + "%");

				//SQL文発行
				ResultSet rs = statement.executeQuery();

				//検索結果を配列に格納
				while(rs.next()){
					SellDTO sellDto = new SellDTO();
					sellDto.setSellId(rs.getInt("sell_id"));
					sellDto.setSellerMemberId(rs.getInt("seller_member_id"));
					sellDto.setPurchaserMemberId(rs.getInt("purchaser_member_id"));
					sellDto.setProductName(rs.getString("product_name"));
					sellDto.setProductType(rs.getString("product_type"));
					sellDto.setPrice(rs.getInt("price"));
					sellDto.setPrefectures(rs.getString("prefectures"));
					sellDto.setRemarks(rs.getString("remarks"));
					sellDto.setDeliveryDays(rs.getInt("delivery_days"));
					sellDto.setProductCondition(rs.getString("product_condition"));
					sellDto.setImagePath(rs.getString("image_path"));
					sellDto.setSellStatus(rs.getString("sell_status"));
					sellDto.setSellDate(rs.getString("sell_date"));
					sellDto.setPurchaseDate(rs.getString("purchase_date"));
					sellDto.setTransferDate(rs.getString("transfer_date"));
					sellDto.setShipmentDate(rs.getString("shipment_date"));
					sellDto.setCompletionDate(rs.getString("completion_date"));
					list.add(sellDto);
				}

			}catch(Exception e){
				throw new IllegalStateException(e);
			}finally{
				if(statement != null){
					try{statement.close();}catch(SQLException ignore){}
				}
				if(statement != null){
					try{con.close();}catch(SQLException ignore){}
				}
			}
			return list;
		}



}
